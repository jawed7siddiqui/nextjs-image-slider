// components/ButtonComponent.js
import '../../../styles/index.scss';

function ButtonComponent() {
    return (
      <button className="btn btn-primary cl">
        Click Me hello
      </button>
    );
  }
  
  export default ButtonComponent;
  