import Image from 'next/image';
import styles from './page.module.css';
import '../../styles/index.scss';
import ButtonComponent from './component/ButtonComponent'; 

export default function Home() {
  return (
    <main className={styles.main}>
      <div className={styles.description}>
        <h1 className={styles.title}>Welcome to My Next.js App</h1>
        
        {/* Use the imported ButtonComponent */}
        <ButtonComponent />

     
      </div>
    </main>
  );
}
